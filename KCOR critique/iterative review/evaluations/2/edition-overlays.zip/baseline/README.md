KCOR

The combined manuscript, its Markdown sources and figures are in documentation/preprint. Method code is in code and scientific inputs and analyses are in the corresponding repo directories.
