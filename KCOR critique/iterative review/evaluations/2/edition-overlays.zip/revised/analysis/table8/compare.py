import importlib.util, inspect, os
from pathlib import Path
from types import SimpleNamespace
import numpy as np
from scipy.optimize import least_squares
PRODUCTION = Path(__file__).resolve().parents[2]/'code/KCOR.py'
adapter=SimpleNamespace()
os.environ['DATASET']='Czech'
def fit_step1(h, t, gamma, theta_start):
    def residual(x):
        k=np.exp(x[0]);theta=x[1]
        Hgom=k*np.expm1(gamma*t)/gamma
        return h-k*np.exp(gamma*t)/(1+theta*Hgom)
    guess=float(np.mean(h[:4]/np.exp(gamma*t[:4])))
    r=least_squares(residual,[np.log(guess),theta_start],
        bounds=([np.log(1e-8),0.],[np.log(.1),100.]),
        xtol=1e-14,ftol=1e-14,gtol=1e-14,max_nfev=10000)
    return dict(k=float(np.exp(r.x[0])),theta=float(r.x[1]),
        objective=float(np.sum(r.fun**2)),success=bool(r.success),
        message=str(r.message))
def initialize(weekly_update="archived"):
    global production_fit, joint_fit
    spec = importlib.util.spec_from_file_location("revised_kcor", PRODUCTION)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    adapter.K = module
    production_fit = module.fit_theta0_gompertz
    source = inspect.getsource(production_fit)
    assert weekly_update == "revised"
    original = "theta_seed, _, _, _, seed_ok = _fit_theta(first_quiet_mask, theta0_init, Delta=None)"
    candidate = """seed = fit_step1(h_arr[first_idx], t_r[first_idx], gamma, theta0_init)
        k_fixed, theta_seed, seed_ok = seed["k"], seed["theta"], seed["success"]
        H_gom_full = _build_H_gom_discrete(k_fixed)"""
    assert source.count(original) == 1
    namespace = dict(vars(module), fit_step1=fit_step1)
    exec(compile(source.replace(original, candidate), "<isolated Step 1 trial>", "exec"), namespace)
    joint_fit = namespace["fit_theta0_gompertz"]
