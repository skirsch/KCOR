# Numerical results

Table 8: `table8/replay.py` reproduces the full ordinary workbook and the person-bootstrap results; the stored 999 draws are in `survivor_validation/table8-draws.npz`. Point estimates and the first matched draw were verified against the integrated implementation. Table 9: `positive_control/replay.py` regenerates the fitted workbook points and the full 999-draw intervals. `quiet_windows/scan.py` regenerates the placement scan. The `survivor_validation`, `information`, `contamination` and `alpha` directories contain numerical results of the specified validation designs and theoretical benchmarks.

The main and supplement Markdown files are authoritative manuscript sources; the combined PDF is a render of both. Historical validation configurations are distinguished from the current method by the manuscript.
